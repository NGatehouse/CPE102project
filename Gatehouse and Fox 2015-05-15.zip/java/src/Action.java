import java.util.List;

/**
 * Created by Nicholas on 5/11/2015.
 */
public interface Action
{
    public List<Point> action(long ticks);
}

