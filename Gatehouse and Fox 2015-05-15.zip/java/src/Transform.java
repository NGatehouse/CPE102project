/**
 * Created by Nicholas on 5/15/2015.
 */
public interface Transform
{
    public Miner try_transform(WorldModel world);
}
