/**
 * Created by Nicholas on 5/10/2015.
 *//*
public class save_load
{
    //all the constants
    public save_world(WorldModel world, file file)
    {
        save_entities(world,file);
        save_background(world,file);
    }

    public save_entities(WorldModel world, file file)
    {
        for(Entity entity;world.get_entities())
        {
            file.write(entities.entity_string(entity) + "\n");
        }
    }

    public save_background(WorldModel world, file file)
    {
        for(int row  = 0; row < world.num_rows; row++)
        {
            for(int col = 0; col < world.num_cols; col++)
            {
                Point p = new Point(col,row);
                file.write("background" + entities.get_name(world.get_background(p)) + " " + col + " " + row + "\n");
            }
        }
    }
}
*/