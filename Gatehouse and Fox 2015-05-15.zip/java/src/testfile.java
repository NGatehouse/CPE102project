import java.lang.System;
/**
 * Created by Luke on 4/28/2015.

public class testfile {
    System.out.println(String.format("%" + numberOfSpaces + "s", ""));
}
*/